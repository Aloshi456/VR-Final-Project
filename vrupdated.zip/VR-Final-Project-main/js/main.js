// VR Heist Simulator - Main Entry Point
// ECE 376 Group 13 - Ryan, Alaa, George
//
// Wires together:
//  - Three.js scene + WebXR
//  - Cannon-ES physics
//  - VR controllers + raycasting
//  - Tool pickups on the spawn table
//  - Random vault unlock sequence + proximity-based progress
//  - Loot collection win condition
//  - Desktop FPS-style fallback for testing without a headset

import * as THREE from 'three';
import * as CANNON from 'cannon-es';
import CannonDebugger from 'cannon-es-debugger';
import { VRButton } from 'three/addons/webxr/VRButton.js';
import { XRControllerModelFactory } from 'three/addons/webxr/XRControllerModelFactory.js';

import { buildVaultRoom } from './scene.js';
import { VaultStateMachine, generateRandomSequence } from './vault.js';
import { PhysicsSync } from './physics.js';
import { DesktopController } from './desktop.js';

let camera, scene, renderer;
let physicsWorld;
let raycaster;
let controller1, controller2;
let controllerGrip1, controllerGrip2;
let desktop;

let vault;
let physicsSync;

let cannonDebugger;
let debugGroup;
let isDebugVisible = false;

const grabbables = new THREE.Group();
const lootBag = [];
const clock = new THREE.Clock();

const hud = {
    tool: document.getElementById('tool-name'),
    stage: document.getElementById('stage-name'),
    lootCount: document.getElementById('loot-count'),
    lootTotal: document.getElementById('loot-total'),
    objective: document.getElementById('objective'),
};

init();

export function setRaycasterFromController(rc, controller) {
    const tmpMatrix = new THREE.Matrix4();
    tmpMatrix.identity().extractRotation(controller.matrixWorld);
    rc.ray.origin.setFromMatrixPosition(controller.matrixWorld);
    rc.ray.direction.set(0, 0, -1).applyMatrix4(tmpMatrix);
}

function init() {
    scene = new THREE.Scene();
    scene.background = new THREE.Color(0x0a0a0f);
    scene.fog = new THREE.Fog(0x0a0a0f, 6, 20);

    camera = new THREE.PerspectiveCamera(
        60,
        window.innerWidth / window.innerHeight,
        0.1,
        100
    );

    // Player starts inside the room.
    camera.position.set(0, 1.6, 1);

    renderer = new THREE.WebGLRenderer({ antialias: true });
    renderer.setPixelRatio(window.devicePixelRatio);
    renderer.setSize(window.innerWidth, window.innerHeight);
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    renderer.xr.enabled = true;
    renderer.setAnimationLoop(animate);

    document.body.appendChild(renderer.domElement);
    document.body.appendChild(VRButton.createButton(renderer));

    renderer.xr.addEventListener('sessionstart', () => {
        console.log('[heist] XR session started');
    });

    renderer.xr.addEventListener('sessionend', () => {
        console.log('[heist] XR session ended');
    });

    window.addEventListener('unhandledrejection', (e) => {
        if (String(e.reason).toLowerCase().includes('xr')) {
            console.error('[heist] XR session rejection:', e.reason);
        }
    });

    physicsWorld = new CANNON.World({
        gravity: new CANNON.Vec3(0, -9.82, 0),
    });

    physicsWorld.broadphase = new CANNON.NaiveBroadphase();
    physicsWorld.solver.iterations = 10;

    physicsSync = new PhysicsSync(physicsWorld);

    const sequence = generateRandomSequence();

    console.log(
        '[heist] sequence:',
        sequence.map(s => `${s.toolLabel}->${s.targetLabel}`).join(', ')
    );

    const roomBuild = buildVaultRoom(scene, physicsWorld, physicsSync, sequence);
    vault = new VaultStateMachine(roomBuild, physicsSync, sequence, onVaultOpen);

    scene.add(grabbables);

    // Tools are grabbable at the start.
    // Loot only becomes grabbable after the vault opens.
    for (const t of roomBuild.tableTools) {
        grabbables.add(t.mesh);
    }

    raycaster = new THREE.Raycaster();

    setupControllers();

    // Desktop fallback for testing without headset/emulator.
    desktop = new DesktopController(
        camera,
        renderer,
        renderer.domElement,
        roomBuild.blockers
    );

    scene.add(desktop.fakeController);

    desktop.onTriggerStart = onSelectStart;
    desktop.onTriggerEnd = onSelectEnd;
    desktop.onSqueeze = () => {};

    debugGroup = new THREE.Group();
    debugGroup.visible = false;
    scene.add(debugGroup);

    cannonDebugger = CannonDebugger(debugGroup, physicsWorld);

    setupKeyboardControls();
    window.addEventListener('resize', onWindowResize);

    hud.lootTotal.textContent = roomBuild.lootItems.length;

    refreshHUD();
}

function setupControllers() {
    // Lab 8-style setup:
    // add controllers directly to the scene, not inside an extra XR rig.
    controller1 = renderer.xr.getController(0);
    controller1.addEventListener('selectstart', onSelectStart);
    controller1.addEventListener('selectend', onSelectEnd);
    scene.add(controller1);

    controller2 = renderer.xr.getController(1);
    controller2.addEventListener('selectstart', onSelectStart);
    controller2.addEventListener('selectend', onSelectEnd);
    scene.add(controller2);

    const factory = new XRControllerModelFactory();

    controllerGrip1 = renderer.xr.getControllerGrip(0);
    controllerGrip1.add(factory.createControllerModel(controllerGrip1));
    scene.add(controllerGrip1);

    controllerGrip2 = renderer.xr.getControllerGrip(1);
    controllerGrip2.add(factory.createControllerModel(controllerGrip2));
    scene.add(controllerGrip2);

    const lineGeo = new THREE.BufferGeometry().setFromPoints([
        new THREE.Vector3(0, 0, 0),
        new THREE.Vector3(0, 0, -1),
    ]);

    const line = new THREE.Line(
        lineGeo,
        new THREE.LineBasicMaterial({ color: 0x66d9ef })
    );

    line.name = 'line';
    line.scale.z = 5;

    controller1.add(line.clone());
    controller2.add(line.clone());
}

function onSelectStart(event) {
    const controller = event.target;

    // In real/emulated VR, use the Three.js XR raycaster helper like Lab 8.
    // In desktop mode, use the custom fake-controller raycaster.
    if (renderer.xr.isPresenting) {
        raycaster.setFromXRController(controller);
    } else {
        setRaycasterFromController(raycaster, controller);
    }

    if (controller.userData.selected) return;

    const MAX_GRAB_DISTANCE = renderer.xr.isPresenting ? 2.0 : 3.0;

    const hits = raycaster
        .intersectObjects(grabbables.children, true)
        .filter(hit => hit.distance <= MAX_GRAB_DISTANCE);

    if (hits.length === 0) return;

    let obj = hits[0].object;

    // If ray hits a child mesh, climb up until we reach the actual grabbable object.
    while (obj && !grabbables.children.includes(obj)) {
        obj = obj.parent;
    }

    if (!obj) return;

    physicsSync.setKinematic(obj, true);

    controller.attach(obj);

    // Put the object in a comfortable held position.
    obj.position.set(0, -0.15, -0.25);
    obj.rotation.set(-Math.PI / 4, 0, 0);

    controller.userData.selected = obj;

    if (obj.material && obj.material.emissive) {
        obj.material.emissive.setHex(0x444400);
    }
}

function onSelectEnd(event) {
    const controller = event.target;
    const obj = controller.userData.selected;

    if (!obj) return;

    grabbables.attach(obj);

    if (obj.material && obj.material.emissive) {
        obj.material.emissive.setHex(0x000000);
    }

    controller.userData.selected = undefined;

    physicsSync.setKinematic(obj, false);

    // Loot dropped over the bag = collected.
    const bagBounds = vault.getLootBagBounds();

    if (bagBounds && bagBounds.containsPoint(obj.position) && obj.userData.lootValue) {
        collectLoot(obj);
    }
}

function collectLoot(mesh) {
    if (lootBag.includes(mesh)) return;

    lootBag.push(mesh);

    physicsSync.remove(mesh);
    grabbables.remove(mesh);

    refreshHUD();

    if (lootBag.length >= parseInt(hud.lootTotal.textContent, 10)) {
        hud.objective.textContent = 'HEIST COMPLETE - You got away clean.';
        hud.objective.style.color = '#7CFC00';
    }
}

function onVaultOpen() {
    hud.objective.textContent = 'Vault open! Grab the gold coins, drop them in the bag.';
    hud.objective.style.color = '#ffcc55';

    // Loot becomes grabbable only after the vault opens.
    for (const loot of vault.room.lootItems) {
        if (!grabbables.children.includes(loot.mesh)) {
            grabbables.add(loot.mesh);
        }
    }
}

function refreshHUD() {
    const heldByDesktop = desktop?.fakeController.userData.selected;
    const heldByC1 = controller1?.userData.selected;
    const heldByC2 = controller2?.userData.selected;

    const held = heldByDesktop || heldByC1 || heldByC2;

    if (held && held.userData.toolName) {
        hud.tool.textContent = held.userData.toolName;
    } else {
        hud.tool.textContent = 'EMPTY HAND';
    }

    hud.stage.textContent = vault.getStageLabel();
    hud.lootCount.textContent = lootBag.length;
}

function setupKeyboardControls() {
    window.addEventListener('keydown', (e) => {
        switch (e.key.toLowerCase()) {
            case 'u':
                vault.forceAdvance();
                refreshHUD();
                break;

            case 'r':
                window.location.reload();
                break;

            case 'b':
                isDebugVisible = !isDebugVisible;
                debugGroup.visible = isDebugVisible;
                break;

            default:
                break;
        }
    });
}

function onWindowResize() {
    camera.aspect = window.innerWidth / window.innerHeight;
    camera.updateProjectionMatrix();
    renderer.setSize(window.innerWidth, window.innerHeight);
}

function updateControllerRay(controller) {
    if (!controller) return;

    const line = controller.getObjectByName('line');

    if (!line) return;

    if (renderer.xr.isPresenting) {
        raycaster.setFromXRController(controller);
    } else {
        setRaycasterFromController(raycaster, controller);
    }

    const hits = raycaster.intersectObjects(grabbables.children, true);

    line.scale.z = hits.length > 0 ? Math.min(hits[0].distance, 5) : 5;
}

function animate() {
    const dt = Math.min(clock.getDelta(), 1 / 30);
    const t = clock.getElapsedTime();

    physicsWorld.step(1 / 60, dt, 3);
    physicsSync.sync();

    if (desktop) {
        desktop.update(dt);
    }

    // Red emergency lamp pulse or other dynamic lights.
    if (scene._dynamicLights) {
        for (const l of scene._dynamicLights) {
            if (l.userData?.tick) {
                l.userData.tick(t);
            }
        }
    }

    vault.update(dt, [
        controller1,
        controller2,
        desktop ? desktop.fakeController : null,
    ]);

    refreshHUD();

    updateControllerRay(controller1);
    updateControllerRay(controller2);

    if (isDebugVisible) {
        cannonDebugger.update();
    }

    renderer.render(scene, camera);
}